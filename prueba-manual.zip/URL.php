<?php
//$URL="10.49.30.49/ideas/";
$URL="10.250.37.182";
//$URL="http://localhost:8080/MQEUpdate";
?>