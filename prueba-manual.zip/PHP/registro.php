<?php 
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

$noreloj = $_POST['noreloj'] ?? '';
$nombre = $_POST['nombre'] ?? '';
$departamento = $_POST['departamento'] ?? '';
$contra = $_POST['contra'] ?? '';
$rol = $_POST['rol'] ?? 0;

$conn = new mysqli("localhost", "root", "", "prueba");
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$hashed_password = password_hash($contra, PASSWORD_DEFAULT);

$sql = "INSERT INTO empleados (NoReloj, Nombre, Departamento, Contra, rol) 
        VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error en prepare: " . $conn->error);
}

$stmt->bind_param('ssssi', $noreloj, $nombre, $departamento, $hashed_password, $rol);

if ($stmt->execute()) {
    // Mostrar mensaje de éxito con JavaScript (popup)
    echo "<script type='text/javascript'>
            alert('Usuario registrado correctamente.');
            window.location.href = './registro.php'; 
          </script>";
} else {
    echo "Error al registrar el usuario: " . $stmt->error;
}

$conn->close();
?>
