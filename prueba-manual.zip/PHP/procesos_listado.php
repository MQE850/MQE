<?php
include 'C:/xampp/htdocs/MQESite/prueba-manual/PHP/conexion.php';

$pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$porPagina = 10;
$inicio = ($pagina - 1) * $porPagina;

$totalRegistros = mysqli_fetch_assoc(mysqli_query($conexion, "SELECT COUNT(*) as total FROM procesos"))['total'];
$totalPaginas = ceil($totalRegistros / $porPagina);

$result = mysqli_query($conexion, "SELECT * FROM procesos ORDER BY fecha DESC LIMIT $inicio, $porPagina");

echo "<div class='class_ProcessList'>";
while ($row = mysqli_fetch_assoc($result)) {
    $id = $row['id_proceso']; // Corrección: id_proceso en lugar de id
    $gen = $row['generaciones_aplica'] ?? 'Desconocido';

    

    echo "<div class='proceso-container' onclick='seleccionarProceso(this, \"$id\")'>
            <div class='proceso' data-id='$id' data-generaciones='$gen' style='display: flex; justify-content: space-between;'>
              <div>
                <strong>{$row['titulo_proceso']}</strong><br>
                <small>{$row['fecha']}</small>
              </div>
              <div style='text-align: right; font-weight: bold;'>
                <small>{$row['id_proceso']}</small><br>
                <small>{$row['generaciones_aplica']}</small>
              </div>
            </div>
          </div>";
}
echo "</div>";

// PAGINACIÓN
echo "<div class='paginacion'>";
for ($i = 1; $i <= $totalPaginas; $i++) {
    echo "<a href='?pagina=$i'>$i</a> ";
}
echo "</div>";
?>
