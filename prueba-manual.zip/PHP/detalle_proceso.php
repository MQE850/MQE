<?php
include 'conexion.php';
$id = $_GET['id_proceso'] ?? 0;
$query = "SELECT * FROM procesos WHERE id_proceso = $id";
$result = mysqli_query($conexion, $query);
if ($row = mysqli_fetch_assoc($result)) {
  echo "<h2>{$row['titulo_proceso']}</h2>";
  echo "<p><strong>Fecha:</strong> {$row['fecha']}</p>";
  echo "<p><strong>Descripción:</strong> {$row['descripcion']}</p>";
  echo "<p><strong>Estado:</strong> {$row['estado']}</p>";
  echo "<p><strong>Generaciones:</strong> {$row['generaciones_aplica']}</p>";
} else {
  echo "No se encontró el proceso.";
}
?>
