<?php 
include("../PHP/conexion.php"); 

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $noreloj = isset($_POST['noreloj']) ? trim($_POST['noreloj']) : '';
    $comentario = isset($_POST['comentario']) ? trim($_POST['comentario']) : '';

    if (!empty($noreloj) || !empty($comentario)) {
        $stmt = $conexion->prepare("INSERT INTO comnoficial (noreloj, comentario) VALUES (?, ?)");

        if ($stmt) {
            $stmt->bind_param("ss", $noreloj, $comentario);
            if ($stmt->execute()) {
                echo json_encode(["success" => true]);
            } else {
                echo json_encode([
                    "success" => false,
                    "message" => "Error al guardar el comentario: " . $stmt->error
                ]);
            }
            $stmt->close();
        } else {
            echo json_encode([
                "success" => false,
                "message" => "Error en la preparación de la consulta: " . $conexion->error
            ]);
        }
    } else {
        echo json_encode([
            "success" => false,
            "message" => "Por favor llena todos los campos."
        ]);
    }

    $conexion->close();
} else {
    echo json_encode([
        "success" => false,
        "message" => "Acceso no permitido."
    ]);
}
?>
