<?php
session_start(); // Inicia la sesión
// Verifica si la variable de sesión 'usuarioActivo' está definida
if (!isset($_SESSION["noreloj"])) {
    header("Location: "); // Redirige al usuario si no está autenticado
    exit();
}
?>