<div id="modal" class="modal">
      <div class="modal-content">
        <span class="close">&times;</span>
        <h2 id="modal-title">Formulario del Proceso</h2>
        <form id="form-proceso" method="POST" action="../PHP/guardar_proceso.php">
          <label>NoReloj:
            <input type="text" name="nodo_reloj" value="<?php echo htmlspecialchars($noreloj_usuario); ?>" readonly>
          </label>
          <label>Fecha: 
            <input type="date" name="fecha" required>
          </label>
          <label>Título de Proceso: 
            <input type="text" name="titulo_proceso" required>
          </label>
          <label>Generaciones que aplican:</label>
          <div style="display: flex; gap: 20px; margin-top: 5px;">
            <label><input type="checkbox" name="generaciones_aplica[]" value="GEN8"> GEN8</label>
            <label><input type="checkbox" name="generaciones_aplica[]" value="GEN9"> GEN9</label>
            <label><input type="checkbox" name="generaciones_aplica[]" value="GEN10"> GEN10</label>
            <label><input type="checkbox" name="generaciones_aplica[]" value="GEN11"> GEN11</label>
          </div>
          <label>Proceso: 
            <input type="text" name="proceso">
          </label>
          <label>Descripción: 
            <input type="text" name="descripcion">
          </label>
          <label>Estado:
            <select name="estado">
              <option value="Pendiente">Pendiente</option>
              <option value="En curso">En curso</option>
              <option value="Completado">Completado</option>
              <option value="Cancelado">Cancelado</option>
            </select>
          </label>
          <label>Responsable: 
            <input type="text" name="responsable">
          </label>
          <label>Duración Estimada: 
            <input type="text" name="duracion_estimada">
          </label>
          <label>Indicadores Clave: 
            <input type="text" name="indicadores_clave">
          </label>
          <label>Documento Asociado: 
            <input type="text" name="documento_asociado">
          </label>
          <label>Frecuencia:
            <select name="frecuencia">
              <option value="Por evento">Por evento</option>
              <option value="Mensual">Mensual</option>
              <option value="Trimestral">Trimestral</option>
              <option value="Anual">Anual</option>
              <option value="Semanal">Semanal</option>
            </select>
          </label>
          <label>Observaciones: 
            <input type="text" name="observaciones">
          </label>
          <button type="submit">Guardar</button>
        </form>      
      </div>
    </div>