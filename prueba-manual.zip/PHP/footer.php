<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$noreloj = $_SESSION['noreloj'] ?? '';
?>
<footer class="footer">
  <div class="footer-left">
    <a href="../index.html"><i class="fa-solid fa-house"></i> Página Principal</a>
    <a href="../html/Generacion.php">Generaciones</a>
    <a href="../html/Procesos.php">Procesos</a>
    <a href="../html/Conceptos.php">Conceptos</a>
    <a href="../html/Comandos.php">Comandos</a>
  </div>
  <div class="footer-center">
    <button id="btn-comentar">Comenta aquí</button>
  </div>
  <div class="footer-right">
    <p><strong>Contacto:</strong></p>
    <p>Ing. Carlos Rosas - Carlos_Rosas@wiwynn.com</p>
    <p>Ing. Mario Jaquez - Mario_Jaquez@wiwynn.com</p>
  </div>
</footer>

<!-- POPUP -->
<div class="popup" id="popup">
  <div class="popup-content">
    <span class="popup-close" id="popup-close">&times;</span>
    <h3>Escribe tu comentario</h3>
    <form id="form-comentario">
      <input
        type="text"
        id="noreloj"
        name="noreloj"
        placeholder="Número de reloj"
        value="<?= htmlspecialchars($noreloj) ?>"
        <?= $noreloj ? 'readonly' : 'required' ?>
      >
      <textarea id="comentario" name="comentario" placeholder="Escribe tu comentario" required></textarea>
      <button type="submit">Enviar</button>
    </form>
    <div id="mensaje"></div>
  </div>
</div>

<!-- Puedes agregar este script en tu JS principal o aquí -->
<script>
document.getElementById("btn-comentar").addEventListener("click", () => {
  document.getElementById("popup").style.display = "block";
});

document.getElementById("popup-close").addEventListener("click", () => {
  document.getElementById("popup").style.display = "none";
  document.getElementById("mensaje").innerText = '';
});

document.getElementById("form-comentario").addEventListener("submit", function (e) {
  e.preventDefault();

  const noreloj = document.getElementById("noreloj").value.trim();
  const comentario = document.getElementById("comentario").value.trim();

  if (!noreloj || !comentario) {
    document.getElementById("mensaje").innerText = "Por favor, completa todos los campos.";
    return;
  }

  const formData = new FormData(this);

  fetch("../PHP/guardar_comentario.php", {
    method: "POST",
    body: formData,
  })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        document.getElementById("mensaje").innerText = "Comentario guardado correctamente.";
        document.getElementById("form-comentario").reset();
        if (document.getElementById("noreloj").hasAttribute("readonly")) {
          document.getElementById("noreloj").value = "<?= htmlspecialchars($noreloj) ?>";
        }
      } else {
        document.getElementById("mensaje").innerText = data.message || "Ocurrió un error.";
      }
    })
    .catch(err => {
      document.getElementById("mensaje").innerText = "Error en la solicitud.";
      console.error(err);
    });
});
</script>
