<?php 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$noreloj = $_SESSION['noreloj'] ?? null;
$rol = $_SESSION['rol'] ?? 'publico';
$nombre = $_SESSION['nombre'] ?? 'Invitado';
$departamento = $_SESSION['departamento'] ?? '';
?>
<header id="navbar">
  <div class="user-logo">
    <div class="logo">
      <img src="../IMAGENES/MQE_LOGOPUTO.png" alt="MQE Logo" />
    </div>

    <?php if ($rol !== 'publico'): ?>
    <div class="user-info" style="color:white;">
      Bienvenido, <?= htmlspecialchars($nombre) ?> (<?= htmlspecialchars($departamento) ?>)
    </div>
    <?php endif; ?>
  </div>
  
  <nav>
    <ul>
      <li><a class="fa-solid fa-house" href="../html/inicio.php" title="Inicio"></a></li>
      <li><a href="../html/Generacion.php">Generación</a></li>
      <li><a href="../html/Procesos.php">Procesos</a></li>
      <li><a href="../html/Conceptos.php">Conceptos</a></li>
      <li><a href="../html/Comandos.php">Comandos</a></li>

      <?php if ($rol === 'admin'): ?>
        <li><a class="fa-solid fa-users" href="#" id="btn-registro" title="Registro de usuarios"></a></li>
      <?php endif; ?>

      <?php if ($rol !== 'publico'): ?>
        <li><a class="fa-solid fa-right-from-bracket" href="../PHP/logout.php" title="Cerrar sesión"></a></li>
      <?php endif; ?>
    </ul>
  </nav>
</header>

<!-- Modal de registro -->
<?php if ($rol === 'admin'): ?>
<div id="modal-registro" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; 
  background: rgba(0,0,0,0.6); justify-content:center; align-items:center; z-index:9999; color: #081032;">
  <div style="background:#fff; padding:20px; border-radius:8px; max-width:400px; width:90%; position:relative;">
    <button id="close-registro" style="position:absolute; top:10px; right:10px; cursor:pointer;">&times;</button>
    <h2>Registrar nuevo usuario</h2>
    <form action="../PHP/registro.php" method="POST"><br>
      <label for="noreloj">NoReloj:</label>
      <input type="text" name="noreloj" id="noreloj" required><br><br>

      <label for="nombre">Nombre:</label>
      <input type="text" name="nombre" id="nombre" required><br><br>

      <label for="departamento">Departamento:</label>
      <input type="text" name="departamento" id="departamento" required><br><br>

      <label for="contra">Contraseña:</label>
      <input type="password" name="contra" id="contra" required><br><br>

      <label for="rol">Rol:</label>
      <select name="rol" id="rol" required>
        <option value="0">General</option>
        <option value="1">Administrador</option>
        <option value="2">Público</option>
      </select><br><br>

      <button type="submit">Registrar</button>
    </form>
  </div>
</div>
<?php endif; ?>

<script>
  document.addEventListener("DOMContentLoaded", () => {
    const btnRegistro = document.getElementById("btn-registro");
    const modal = document.getElementById("modal-registro");
    const btnClose = document.getElementById("close-registro");

    if (btnRegistro && modal && btnClose) {
      btnRegistro.addEventListener("click", e => {
        e.preventDefault();
        modal.style.display = "flex";
      });

      btnClose.addEventListener("click", () => {
        modal.style.display = "none";
      });

      window.addEventListener("click", (e) => {
        if (e.target === modal) {
          modal.style.display = "none";
        }
      });
    }
  });
</script>
