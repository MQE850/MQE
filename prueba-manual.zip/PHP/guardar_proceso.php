<?php
include 'conexion.php';

$nodo_reloj = $_POST['nodo_reloj'];
$fecha = $_POST['fecha'];
$titulo_proceso = $_POST['titulo_proceso'];
$generaciones_aplica = isset($_POST['generaciones_aplica']) ? implode(", ", $_POST['generaciones_aplica']) : '';
$proceso = $_POST['proceso'];
$descripcion = $_POST['descripcion'];
$estado = $_POST['estado'];
$responsable = $_POST['responsable'];
$duracion_estimada = $_POST['duracion_estimada'];
$indicadores_clave = $_POST['indicadores_clave'];
$documento_asociado = $_POST['documento_asociado'];
$frecuencia = $_POST['frecuencia'];
$observaciones = $_POST['observaciones'];

$sql = "INSERT INTO procesos (NoReloj, fecha, titulo, generaciones, proceso, descripcion, estado, responsable, duracion_estimada, indicadores_clave, documento_asociado, frecuencia, observaciones)
        VALUES ('$nodo_reloj', '$fecha', '$titulo_proceso', '$generaciones_aplica', '$proceso', '$descripcion', '$estado', '$responsable', '$duracion_estimada', '$indicadores_clave', '$documento_asociado', '$frecuencia', '$observaciones')";

if ($conexion->query($sql) === TRUE) {
    header("Location: ../html/Procesos.php");
    exit();
} else {
    echo "Error al guardar: " . $conexion->error;
}
?>
