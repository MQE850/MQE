<?php
session_start();
$nombre_usuario = $_SESSION['usuario_nombre'];
$servername = "localhost"; // Cambia esto según tu servidor
$username = "root"; // Cambia esto según tu usuario
$password = ""; // Cambia esto según tu contraseña
$dbname = "prueba"; // Cambia esto según tu base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}


// Obtener los datos del formulario
$nombre = $_POST['nombre'];
$fecha = $_POST['fecha'];
$nodo_reloj = $_POST['nodo_reloj'];
$titulo_proceso = $_POST['titulo_proceso'];
$generaciones_aplica = $_POST['generaciones_aplica'];
$proceso = $_POST['proceso'];
$descripcion = $_POST['descripcion'];
$estado = $_POST['estado'];
$responsable = $_POST['responsable'];
$duracion_estimada = $_POST['duracion_estimada'];
$indicadores_clave = $_POST['indicadores_clave'];
$documento_asociado = $_POST['documento_asociado'];
$frecuencia = $_POST['frecuencia'];
$observaciones = $_POST['observaciones'];

// Preparar la consulta SQL
$sql = "INSERT INTO procesos (nombre, fecha, nodo_reloj, titulo_proceso, generaciones_aplica, proceso, descripcion, estado, responsable, duracion_estimada, indicadores_clave, documento_asociado, frecuencia, observaciones)
VALUES ('$nombre', '$fecha', '$nodo_reloj', '$titulo_proceso', '$generaciones_aplica', '$proceso', '$descripcion', '$estado', '$responsable', '$duracion_estimada', '$indicadores_clave', '$documento_asociado', '$frecuencia', '$observaciones')";

// Ejecutar la consulta
if ($conn->query($sql) === TRUE) {
    echo "Nuevo proceso agregado exitosamente";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Cerrar la conexión
$conn->close();
?>
