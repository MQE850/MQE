<?php
session_start();

$noreloj = $_POST['noreloj'] ?? '';
$contra = $_POST['contra'] ?? '';

$conn = new mysqli("localhost", "root", "", "prueba");

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$sql = "SELECT * FROM empleados WHERE NoReloj = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $noreloj);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 1) {
    $usuario = $resultado->fetch_assoc();

    if (isset($usuario['Activo']) && $usuario['Activo'] == 0) {
        header("Location: ../HTML/login.php?error=sinacceso");
        exit();
    }

    if (password_verify($contra, $usuario['Contra'])) {
        // Guardar datos en la sesión
        $_SESSION['noreloj'] = $usuario['NoReloj'];
        $_SESSION['nombre'] = $usuario['Nombre'];
        $_SESSION['departamento'] = $usuario['Departamento'];

        // Convertir rol numérico a texto
        $rol_num = $usuario['rol'];
        if ($rol_num == 1) {
            $_SESSION['rol'] = 'admin';
        } elseif ($rol_num == 0) {
            $_SESSION['rol'] = 'general';
        } elseif ($rol_num == 2) {
            $_SESSION['rol'] = 'publico';
        } else {
            $_SESSION['rol'] = 'publico'; // Valor por defecto seguro
        }

        header("Location: ../HTML/inicio.php");
        exit();
    } else {
        header("Location: ../HTML/login.php?error=pass");
        exit();
    }
} else {
    header("Location: ../HTML/login.php?error=nousuario");
    exit();
}

$conn->close();
?>
