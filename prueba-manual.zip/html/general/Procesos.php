<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Procesos</title>
  <link rel="stylesheet" href="../../CSS/Procesos.css" />
  <link rel="stylesheet" href="../../fotawesome/css/all.min.css">
  <link rel="stylesheet" href="../../CSS/footer.css" />
  </head>
<body>

  <!-- NAVBAR banner -->
  <header id="id_bannerNav">
    <div class="class_logo">Generaciones</div>
    <nav>
    <ul>
        <li><a class="fa-solid fa-house" href="./inicio.php"></a></li>
        <li><a href="./Generacion.php">Generacion</a></li>
        <li><a href="./Procesos.php">Procesos</a></li>
        <li><a href="./Conceptos.html">Conceptos</a></li>
        <li><a href="./Comandos.html">Comandos</a></li>
        <li><a class="fa-solid fa-users" href="./registro.html"></a></li>
        <li><a class="fa-solid fa-right-from-bracket" href="../PHP/logout.php"></a></li>
      </ul>
    </nav>
  </header>

  <br>

  <!-- CONTENEDOR PRINCIPAL -->
<div class="class_MainProcessContainer">

  <!-- BUSCADOR -->
  <div class="class_NavContainer">
    <input type="text" id="id_searchBar" placeholder="Ingrese el proceso a buscar..." />
  </div>

  <!--  CONTENEDOR DE PROCESOS -->
  <div class="class_ProcessContainer">

    <section class="class_ProcessDetails" id="id_ProcessDetails">
      <p>Selecciona un proceso para ver los detalles.</p>
      <!-- LISTADO ORIGINAL -->
      <div id="id_ProcessList">
        <?php include '../../PHP/procesos_listado.php'; ?>
      </div>
    </section>
  </div>

</div>

<footer class="footer">
    <div class="footer-left">
      <a href="../index.html"><i class="fa-solid fa-house"></i> Página Principal</a>
    </div>
    <div class="footer-center">
      <button id="btn-comentar">Comenta aquí</button>
    </div>
    <div class="footer-right">
      <p><strong>Contacto:</strong></p>
      <p>Ing. Carlos Rosas - Carlos_Rosas@wiwynn.com</p>
      <p>Ing. Mario Jaquez - Mario_Jaquez@wiwynn.com</p>
    </div>
  </footer>
  <div class="popup" id="popup" style="display: none;">
    <div class="popup-content">
        <span class="popup-close" id="popup-close">&times;</span>
        <h3>Escribe tu comentario</h3>
        <form id="comentarioForm">
            <input type="text" name="noreloj" placeholder="Tu número de reloj" required>
            <textarea name="comentario" placeholder="Tu comentario..." required></textarea>
            <button type="submit">Enviar</button>
        </form>
        <div id="mensaje"></div>
    </div>
</div>

<script src="../../JS/guardarcom.js"></script>


</body>
</html>
