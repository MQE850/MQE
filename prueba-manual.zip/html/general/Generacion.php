<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$noreloj_usuario = isset($_SESSION['noreloj']) ? $_SESSION['noreloj'] : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generaciones</title>
    <link rel="stylesheet" href="../../CSS/Generacion.css">
    <link rel="stylesheet" href="../../CSS/footer.css" />

    <link rel="stylesheet" href="../../fotawesome/css/all.min.css">
    <style>
      /* Estilos para el modal */

      .modal {
          display: none; 
          position: fixed;
          z-index: 1;
          left: 0;
          top: 0;
          width: 100%;
          height: 100%;
          background-color: rgba(0, 0, 0, 0.4); /* Fondo oscuro */
          overflow: auto; 
          color: black;
      }

      .modal-content {
          background-color: #fefefe;
          margin: 15% auto;
          padding: 20px;
          border: 1px solid #888;
          width: 80%;
      }

      .close {
          color: #aaa;
          float: right;
          font-size: 28px;
          font-weight: bold;
      }

      .close:hover,
      .close:focus {
          color: black;
          text-decoration: none;
          cursor: pointer;
      }

      /* Estilos adicionales */
      label {
          display: block;
          margin: 10px 0 5px;
      }

      input, textarea, select {
          width: 100%;
          padding: 8px;
          margin-bottom: 10px;
          border: 1px solid #ccc;
          border-radius: 4px;
      }

      button[type="submit"] {
          background-color: #4CAF50;
          color: white;
          border: none;
          padding: 10px 15px;
          cursor: pointer;
      }

      button[type="submit"]:hover {
          background-color: #45a049;
      }

      .modal-title h2{
        color: black;
      }

      .generaciones-texto p{
        color: #fff;
      }
  </style>
</head>
<body>
  <header id="navbar">
      <div class="logo">GENERACIONES</div>
      <nav>
      <ul>
        <li><a class="fa-solid fa-house" href="./inicio.php"></a></li>
        <li><a href="./Generacion.php">Generacion</a></li>
        <li><a href="./Procesos.php">Procesos</a></li>
        <li><a href="./Conceptos.html">Conceptos</a></li>
        <li><a href="./Comandos.html">Comandos</a></li>
        <li><a class="fa-solid fa-users" href="./registro.html"></a></li>
        <li><a class="fa-solid fa-right-from-bracket" href="../PHP/logout.php"></a></li>
      </ul>
      </nav>
    </header>

<br>
    <section class="generaciones-section">
      <div class="generaciones-imagen">
        <img src="../../IMAGENES/1.jpg" alt="Imagen de una generación" />
        <p class="imagen-credit"></p>
      </div>
    
      <div class="generaciones-texto">
        <h2>Generación 8</h2>
        <p>
          La generación Alfa incluye a aquellos nacidos a partir del año 2010. Se caracterizan 
          por haber crecido en un entorno completamente digital, rodeados de tecnología, inteligencia artificial 
          y conectividad constante. Esta generación está redefiniendo la forma en la que aprendemos y nos comunicamos.
        </p>
    
        <div class="botones-acciones">
          <button class="btn-modal" data-action="agregar">Agregar</button>       
        </div>
        
      </div>
    </section>
    <section class="generaciones-section">  
      <div class="generaciones-texto">
        <h2>Generación 9</h2>
        <p>
          La generación Alfa incluye a aquellos nacidos a partir del año 2010. Se caracterizan 
          por haber crecido en un entorno completamente digital, rodeados de tecnología, inteligencia artificial 
          y conectividad constante. Esta generación está redefiniendo la forma en la que aprendemos y nos comunicamos.
        </p>
    
        <div class="botones-acciones">
        <button class="btn-modal" data-action="agregar">Agregar</button>       
        </div>
        
      </div>
      <div class="generaciones-imagen">
        <img src="../../IMAGENES/1.jpg" alt="Imagen de una generación" />
        <p class="imagen-credit"></p>
      </div>
    </section>
    <section class="generaciones-section">
      <div class="generaciones-imagen">
        <img src="../../IMAGENES/1.jpg" alt="Imagen de una generación" />
        <p class="imagen-credit"></p>
      </div>
    
      <div class="generaciones-texto">
        <h2>Generación 10</h2>
        <p>
          La generación Alfa incluye a aquellos nacidos a partir del año 2010. Se caracterizan 
          por haber crecido en un entorno completamente digital, rodeados de tecnología, inteligencia artificial 
          y conectividad constante. Esta generación está redefiniendo la forma en la que aprendemos y nos comunicamos.
        </p>
    
        <div class="botones-acciones">
        <button class="btn-modal" data-action="agregar">Agregar</button>       
        </div>
        
      </div>
    </section>
    <section class="generaciones-section">  
      <div class="generaciones-texto">
        <h2>Generación 11</h2>
        <p>
          La generación Alfa incluye a aquellos nacidos a partir del año 2010. Se caracterizan 
          por haber crecido en un entorno completamente digital, rodeados de tecnología, inteligencia artificial 
          y conectividad constante. Esta generación está redefiniendo la forma en la que aprendemos y nos comunicamos.
        </p>
    
        <div class="botones-acciones">
        <button class="btn-modal" data-action="agregar">Agregar</button>       
        </div>
        
      </div>
      <div class="generaciones-imagen">
        <img src="../../IMAGENES/1.jpg" alt="Imagen de una generación" />
        <p class="imagen-credit"></p>
      </div>
    </section>
    
    <div id="modal" class="modal">
      <div class="modal-content">
        <span class="close">&times;</span>
        <h2 id="modal-title">Formulario del Proceso</h2>
        <form id="form-proceso" method="POST" action="../PHP/guardar_proceso.php">
          <label>NoReloj:
            <input type="text" name="nodo_reloj" value="<?php echo htmlspecialchars($noreloj_usuario); ?>" readonly>
          </label>
          <label>Fecha: 
            <input type="date" name="fecha" required>
          </label>
          <label>Título de Proceso: 
            <input type="text" name="titulo_proceso" required>
          </label>
          <label>Generaciones que aplican:</label>
          <div style="display: flex; gap: 20px; margin-top: 5px;">
            <label><input type="checkbox" name="generaciones_aplica[]" value="GEN8"> GEN8</label>
            <label><input type="checkbox" name="generaciones_aplica[]" value="GEN9"> GEN9</label>
            <label><input type="checkbox" name="generaciones_aplica[]" value="GEN10"> GEN10</label>
            <label><input type="checkbox" name="generaciones_aplica[]" value="GEN11"> GEN11</label>
          </div>
          <label>Proceso: 
            <input type="text" name="proceso">
          </label>
          <label>Descripción: 
            <input type="text" name="descripcion">
          </label>
          <label>Estado:
            <select name="estado">
              <option value="Pendiente">Pendiente</option>
              <option value="En curso">En curso</option>
              <option value="Completado">Completado</option>
              <option value="Cancelado">Cancelado</option>
            </select>
          </label>
          <label>Responsable: 
            <input type="text" name="responsable">
          </label>
          <label>Duración Estimada: 
            <input type="text" name="duracion_estimada">
          </label>
          <label>Indicadores Clave: 
            <input type="text" name="indicadores_clave">
          </label>
          <label>Documento Asociado: 
            <input type="text" name="documento_asociado">
          </label>
          <label>Frecuencia:
            <select name="frecuencia">
              <option value="Por evento">Por evento</option>
              <option value="Mensual">Mensual</option>
              <option value="Trimestral">Trimestral</option>
              <option value="Anual">Anual</option>
              <option value="Semanal">Semanal</option>
            </select>
          </label>
          <label>Observaciones: 
            <input type="text" name="observaciones">
          </label>
          <button type="submit">Guardar</button>
        </form>      
      </div>
    </div>
    
    <footer class="footer">
    <div class="footer-left">
      <a href="../index.html"><i class="fa-solid fa-house"></i> Página Principal</a>
    </div>
    <div class="footer-center">
      <button id="btn-comentar">Comenta aquí</button>
    </div>
    <div class="footer-right">
      <p><strong>Contacto:</strong></p>
      <p>Ing. Carlos Rosas - Carlos_Rosas@wiwynn.com</p>
      <p>Ing. Mario Jaquez - Mario_Jaquez@wiwynn.com</p>
    </div>
  </footer>
  <div class="popup" id="popup" style="display: none;">
    <div class="popup-content">
        <span class="popup-close" id="popup-close">&times;</span>
        <h3>Escribe tu comentario</h3>
        <form id="comentarioForm">
            <input type="text" name="noreloj" placeholder="Tu número de reloj" required>
            <textarea name="comentario" placeholder="Tu comentario..." required></textarea>
            <button type="submit">Enviar</button>
        </form>
        <div id="mensaje"></div>
    </div>
</div>

<script src="../../JS/guardarcom.js"></script>
<script src="../../JS/Generaciones.js"></script>
  
</body>
</html>
