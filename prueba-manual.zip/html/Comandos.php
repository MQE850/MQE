<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Comandos</title>
  <link rel="stylesheet" href="../CSS/Comandos.css" />
  <link rel="stylesheet" href="../CSS/footer.css" />
  <link rel="stylesheet" href="../CSS/navbar.css" />
  <link rel="stylesheet" href="../CSS/Generales.css">
  <link rel="stylesheet" href="../fotawesome/css/all.min.css">
</head>
<body>
  <?php include '../PHP/navbar.php'; ?>

  <input type="text" id="buscador" placeholder="Buscar...">

  <div class="carrusel-container">
    <button id="prev" class="nav left">&#8592;</button>
    <div class="carrusel" id="carrusel"></div>
    <button id="next" class="nav right">&#8594;</button>
  </div>

  <?php include '../PHP/footer.php'; ?>

  <script src="../JS/guardarcom.js"></script>
  <script src="../JS/Comandos.js"></script>
</body>
</html>
