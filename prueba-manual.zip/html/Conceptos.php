<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Conceptos Técnicos</title>
  <link rel="stylesheet" href="../CSS/Conceptos.css" />
  <link rel="stylesheet" href="../CSS/navbar.css" />
  <link rel="stylesheet" href="../CSS/footer.css" />
  <link rel="stylesheet" href="../CSS/Generales.css">
  <link rel="stylesheet" href="../fotawesome/css/all.min.css">
</head>
<body>
<?php include '../PHP/navbar.php'; ?>

<div id="popup" class="popup">No se encontró el concepto.</div>
<section class="conceptos">
  <h2>Conceptos</h2>
  <div class="buscador">
    <input type="text" id="inputBusqueda" placeholder="Buscar concepto..." />
    <button onclick="buscarConcepto()">Buscar</button>
  </div>
  <br>
  <div class="concepto-grid">
    <div class="card" id="mqe">
      <div class="card-inner">
        <div class="card-front">
          <img src="../IMAGENES/MQE.jpg" alt="MQE">
          <h3>MQE</h3>
        </div>
        <div class="card-back">
          <h3>Manufacturing Quality Engineer</h3>
          <p>Es un rol en la industria que se enfoca en asegurar que los productos se fabriquen cumpliendo con los estándares de calidad establecidos...</p>
        </div>
      </div>
    </div>

    <div class="card" id="ac-cycle">
      <div class="card-inner">
        <div class="card-front">
          <img src="../IMAGENES/I1.jpg" alt="AC Cycle">
          <h3>AC Cycle</h3>
        </div>
        <div class="card-back">
          <h3>Ciclo de Corriente Alterna</h3>
          <p>Consiste en encender y apagar repetidamente un dispositivo bajo corriente alterna...</p>
        </div>
      </div>
    </div>

    <div class="card" id="dc-cycle">
      <div class="card-inner">
        <div class="card-front">
          <img src="../IMAGENES/I2.jpg" alt="DC Cycle">
          <h3>DC Cycle</h3>
        </div>
        <div class="card-back">
          <h3>Ciclo de Corriente Continua</h3>
          <p>Proceso de aplicar y quitar energía DC repetidamente a un sistema...</p>
        </div>
      </div>
    </div>

    <div class="card" id="os-reboot">
      <div class="card">
        <div class="card-inner">
          <div class="card-front">
            <img src="../IMAGENES/I3.jpg" alt="OS Reboot">
            <h3>OS Reboot</h3>
          </div>
          <div class="card-back">
            <h3>Reinicio del Sistema Operativo</h3>
            <p>Proceso mediante el cual el sistema operativo se reinicia completamente sin cortar la energía física del equipo. Se utiliza para validar la estabilidad del software y hardware tras un reinicio.</p>
          </div>
        </div>
      </div>
    </div>
    
    <div class="card" id="bmc">
      <div class="card">
        <div class="card-inner">
          <div class="card-front">
            <img src="../IMAGENES/I4.jpg" alt="BMC">
            <h3>BMC</h3>
          </div>
          <div class="card-back">
            <h3>Baseboard Management Controller</h3>
            <p>Es un microcontrolador integrado en servidores que permite la gestión remota del sistema, incluyendo encendido/apagado, monitoreo de sensores, y acceso remoto a la consola, incluso si el sistema operativo no responde.</p>
          </div>
        </div>
      </div>
    </div>

    <div class="card" id="servidor">
      <div class="card">
        <div class="card-inner">
          <div class="card-front">
            <img src="../IMAGENES/I5.jpg" alt="Servidor">
            <h3>Servidor</h3>
          </div>
          <div class="card-back">
            <h3>Servidor</h3>
            <p>Es un equipo diseñado para proporcionar servicios, recursos o datos a otras computadoras en una red. Generalmente se caracteriza por su alto rendimiento, disponibilidad y capacidad de operación continua.</p>
          </div>
        </div>
      </div>
    </div>

        <div class="card" id="blade">
          <div class="card">
            <div class="card-inner">
              <div class="card-front">
                <img src="../IMAGENES/I6.jpg" alt="Blade Server">
                <h3>Blade</h3>
              </div>
              <div class="card-back">
                <h3>Blade Server</h3>
                <p>Es un servidor modular que se inserta en un chasis común con otros blades. Comparte energía, refrigeración y red, optimizando espacio y eficiencia en centros de datos.</p>
              </div>
            </div>
          </div>
        </div>

        <div class="card" id="cpld">
          <div class="card">
            <div class="card-inner">
              <div class="card-front">
                <img src="../IMAGENES/I7.jpg" alt="CPLD">
                <h3>CPLD</h3>
              </div>
              <div class="card-back">
                <h3>Complex Programmable Logic Device</h3>
                <p>Es un dispositivo lógico programable que permite implementar funciones de control de hardware como gestión de señales, encendido, reinicios, entre otros, siendo clave en placas base y servidores.</p>
              </div>
            </div>
          </div>
        </div>

        <div class="card" id="bios">
          <div class="card">
            <div class="card-inner">
              <div class="card-front">
                <img src="../IMAGENES/I8.jpg" alt="BIOS">
                <h3>BIOS</h3>
              </div>
              <div class="card-back">
                <h3>Basic Input/Output System</h3>
                <p>Firmware que se ejecuta al encender el equipo y se encarga de inicializar el hardware y cargar el sistema operativo. Permite la configuración básica del sistema a bajo nivel.</p>
              </div>
            </div>
          </div>
        </div>

        <div class="card" id="hpm">
          <div class="card">
            <div class="card-inner">
              <div class="card-front">
                <img src="../IMAGENES/I9.jpg" alt="HPM">
                <h3>HPM</h3>
              </div>
              <div class="card-back">
                <h3>Hardware Platform Management</h3>
                <p>Conjunto de especificaciones que define cómo se gestiona el hardware en plataformas como servidores, incluyendo actualizaciones de firmware, monitoreo de sensores y gestión remota.</p>
              </div>
            </div>
          </div>
        </div>

        <div class="card" id="cerberus">
          <div class="card">
            <div class="card-inner">
              <div class="card-front">
                <img src="../IMAGENES/I10.jpg" alt="Cerberus">
                <h3>Cerberus</h3>
              </div>
              <div class="card-back">
                <h3>Cerberus</h3>
                <p>Es un sistema interno utilizado para monitorear y registrar eventos críticos de hardware en pruebas. Permite validar la integridad de los ciclos de encendido, fallos y respuestas del sistema durante validaciones de calidad.</p>
              </div>
            </div>
          </div>
        </div>

        <div class="card" id="ipv6">
          <div class="card">
            <div class="card-inner">
              <div class="card-front">
                <img src="../IMAGENES/I11.jpg" alt="IPv6">
                <h3>IPv6</h3>
              </div>
              <div class="card-back">
                <h3>IPv6 (Internet Protocol v6)</h3>
                <p>Protocolo de red que reemplaza a IPv4, diseñado para resolver la escasez de direcciones. Soporta 128 bits por dirección y mejora seguridad y rendimiento en la comunicación de red.</p>
              </div>
            </div>
          </div>
        </div>

    <div class="card" id="ipv4">
      <div class="card">
        <div class="card-inner">
          <div class="card-front">
            <img src="../IMAGENES/I12.jpg" alt="IPv4">
            <h3>IPv4</h3>
          </div>
          <div class="card-back">
            <h3>IPv4 (Internet Protocol v4)</h3>
            <p>Protocolo de red más utilizado históricamente. Usa direcciones de 32 bits y permite la comunicación entre dispositivos en redes LAN y WAN.</p>
          </div>
        </div>
      </div>
    </div>

    <div class="card" id="Maquina-Virtual">
      <div class="card">
        <div class="card-inner">
          <div class="card-front">
            <img src="../IMAGENES/I13.jpg" alt="Máquina Virtual">
            <h3>Máquina Virtual</h3>
          </div>
          <div class="card-back">
            <h3>Máquina Virtual</h3>
            <p>Es una emulación de un sistema operativo o entorno de hardware que corre dentro de otro sistema. Permite ejecutar múltiples sistemas operativos sobre el mismo hardware físico.</p>
          </div>
        </div>
      </div>
    </div>

    <div class="card" id="manticore">
      <div class="card">
        <div class="card-inner">
          <div class="card-front">
            <img src="../IMAGENES/I14.jpg" alt="Manticore">
            <h3>Manticore</h3>
          </div>
          <div class="card-back">
            <h3>Manticore</h3>
            <p>Es una plataforma interna utilizada para pruebas automatizadas de hardware. Permite ejecutar test de validación y control de firmware en servidores y sistemas complejos.</p>
          </div>
        </div>
      </div>
    </div>

    <div class="card" id="tip">
      <div class="card">
        <div class="card-inner">
          <div class="card-front">
            <img src="../IMAGENES/I15.jpg" alt="TIP">
            <h3>TIP</h3>
          </div>
          <div class="card-back">
            <h3>Test Infrastructure Platform</h3>
            <p>Framework o infraestructura que permite ejecutar pruebas en múltiples plataformas de hardware y firmware, recopilando datos y resultados de forma centralizada.</p>
          </div>
        </div>
      </div>
    </div>

    <div class="card" id="glacer-pic">
      <div class="card">
        <div class="card-inner">
          <div class="card-front">
            <img src="../IMAGENES/I16.jpg" alt="Glacier PIC">
            <h3>Glacier PIC</h3>
          </div>
          <div class="card-back">
            <h3>Glacier PIC</h3>
            <p>Controlador especializado usado en servidores para gestionar puertos de expansión y comunicación de baja velocidad, especialmente en plataformas de validación.</p>
          </div>
        </div>
      </div>
    </div>

    <div class="card" id="e1.s">
      <div class="card">
        <div class="card-inner">
          <div class="card-front">
            <img src="../IMAGENES/I17.jpg" alt="E1.S">
            <h3>E1.S</h3>
          </div>
          <div class="card-back">
            <h3>E1.S (Enterprise and Datacenter SSD)</h3>
            <p>Especificación de factor de forma para SSDs NVMe, optimizada para centros de datos. Ofrece mayor densidad, eficiencia térmica y rendimiento que M.2 en servidores.</p>
          </div>
        </div>
      </div>
    </div>

    <div class="card" id="m.2">
      <div class="card">
        <div class="card-inner">
          <div class="card-front">
            <img src="../IMAGENES/I18.jpg" alt="M.2">
            <h3>M.2</h3>
          </div>
          <div class="card-back">
            <h3>M.2</h3>
            <p>Formato físico compacto para unidades SSD y tarjetas Wi-Fi. Se conecta directamente a la placa base y ofrece alta velocidad mediante interfaces como NVMe o SATA.</p>
          </div>
        </div>
      </div>
    </div>

    <div class="card" id="cloud-most">
      <div class="card">
        <div class="card-inner">
          <div class="card-front">
            <img src="../IMAGENES/I19.jpg" alt="Cloud MOST">
            <h3>Cloud MOST</h3>
          </div>
          <div class="card-back">
            <h3>Cloud MOST</h3>
            <p>Es una plataforma interna basada en la nube para monitoreo, validación y gestión de pruebas en sistemas de hardware, utilizada durante el desarrollo de servidores.</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="popup" id="popup">Concepto no encontrado</div>
  <?php include '../PHP/footer.php'; ?>
  <script src="../JS/cards.js"></script>
</body>
</html>
