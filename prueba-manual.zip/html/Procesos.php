<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Procesos</title>
  <link rel="stylesheet" href="../CSS/Procesos.css" />
  <link rel="stylesheet" href="../fotawesome/css/all.min.css">
  <link rel="stylesheet" href="../CSS/footer.css" />
  <link rel="stylesheet" href="../CSS/navbar.css" />
  </head>
<body>
<?php include '../PHP/navbar.php'; ?>

  <!-- NAVBAR banner -->
<br>
  <!-- CONTENEDOR PRINCIPAL -->
<div class="class_MainProcessContainer">

  <!-- BUSCADOR -->
  <div class="class_NavContainer">
    <input type="text" id="id_searchBar" placeholder="Ingrese el proceso a buscar..." />
  </div>

  <!--  CONTENEDOR DE PROCESOS -->
  <div class="class_ProcessContainer">

    <section class="class_ProcessDetails" id="id_ProcessDetails">
      <p>Selecciona un proceso para ver los detalles.</p>
      <!-- LISTADO ORIGINAL -->
      <div id="id_ProcessList">
        <?php include '../PHP/procesos_listado.php'; ?>
      </div>
    </section>
  </div>

</div>

<?php include '../PHP/footer.php'; ?>
<script src="../../JS/guardarcom.js"></script>
</body>
</html>
