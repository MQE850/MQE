<?php
session_start();
$noreloj_usuario = $_SESSION['noreloj'] ?? '';
$rol_usuario = $_SESSION['rol'] ?? '3';
$tiene_permiso = ($rol_usuario !== '3');
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Generaciones</title>
  <link rel="stylesheet" href="../CSS/Generacion.css">
  <link rel="stylesheet" href="../CSS/footer.css" />
  <link rel="stylesheet" href="../CSS/navbar.css" />
  <link rel="stylesheet" href="../CSS/Generales.css">
  <link rel="stylesheet" href="../fotawesome/css/all.min.css">
</head>
<body>
<?php include '../PHP/navbar.php'; ?>
<br>

<?php
$generaciones = [
  8 => "La generación Alfa incluye a aquellos nacidos a partir del año 2010. Se caracterizan 
        por haber crecido en un entorno completamente digital, rodeados de tecnología, inteligencia artificial 
        y conectividad constante. Esta generación está redefiniendo la forma en la que aprendemos y nos comunicamos.",
  9 => "La generación Alfa incluye a aquellos nacidos a partir del año 2010...",
  10 => "La generación Alfa incluye a aquellos nacidos a partir del año 2010...",
  11 => "La generación Alfa incluye a aquellos nacidos a partir del año 2010..."
];
foreach ($generaciones as $num => $texto):
?>
<section class="generaciones-section <?= $num % 2 === 0 ? '' : 'reverse' ?>">
  <?php if ($num % 2 === 0): ?>
    <div class="generaciones-imagen">
      <img src="../IMAGENES/1.jpg" alt="Imagen de una generación" />
      <p class="imagen-credit"></p>
    </div>
  <?php endif; ?>

  <div class="generaciones-texto">
    <h2>Generación <?= $num ?></h2>
    <p><?= $texto ?></p>
    <?php if ($tiene_permiso): ?>
      <div class="botones-acciones">
        <button class="btn-modal" data-action="agregar">Agregar</button>
      </div>
    <?php endif; ?>
  </div>

  <?php if ($num % 2 !== 0): ?>
    <div class="generaciones-imagen">
      <img src="../IMAGENES/1.jpg" alt="Imagen de una generación" />
      <p class="imagen-credit"></p>
    </div>
  <?php endif; ?>
</section>
<?php endforeach; ?>

<?php if ($tiene_permiso): ?>
<div id="modal" class="modal" style="display:none;">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h2 id="modal-title">Formulario del Proceso</h2> <!-- ID agregado aquí -->
    <form id="form-proceso" method="POST" action="../PHP/guardar_proceso.php"> <!-- ID agregado aquí -->
      <input type="hidden" name="nodo_reloj" value="<?= htmlspecialchars($noreloj_usuario) ?>">
      
      <label for="nombre">Nombre del Proceso:</label>
      <input type="text" name="nombre" required>

      <label for="descripcion">Descripción:</label>
      <textarea name="descripcion" required></textarea>

      <button type="submit">Guardar</button>
    </form>
  </div>
</div>
<?php endif; ?>
<script src="../JS/guardarcom.js"></script>
<script src="../JS/Generaciones.js"></script>
<?php include '../PHP/footer.php'; ?>
</body>
</html>
