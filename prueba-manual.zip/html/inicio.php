
<?php
session_start();
if (isset($_SESSION['nombre'])) {
    $nombre_usuario = $_SESSION['nombre'];  // Asignar el nombre de la sesión
} else {
    $nombre_usuario = 'Usuario no autenticado'; // En caso de que no haya sesión
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="icon" type="image/png" href="../IMAGENES/MQE_LOGOPUTO.png">
  <title>MQE - Manufacturing Quality Engineer</title>
  <link rel="stylesheet" href="../CSS/styles.css">
  <link rel="stylesheet" href="../fotawesome/css/all.min.css">
  <link rel="stylesheet" href="../CSS/footer.css" />
  <link rel="stylesheet" href="../CSS/navbar.css" />
  <link rel="stylesheet" href="../CSS/Generales.css">
</head>
<body>

<?php include '../PHP/navbar.php';?> <!-- header -->

  <main>
    <div class="text-content">
      <h1>Manual de procesos<br></h1>
      <p>Guías, conceptos y procedimientos - Todos somos Wiwynn.</p>
      <a href="./introducccion.php" class="listen-btn">Ver más</a>
    </div>
    <div class="image-content">
      <img src="../IMAGENES/1.jpg" alt="Imagen principal" />
    </div>
  </main>

  <div class="bottom-banner">
    Simplificamos lo complejo.<br>
  </div>

  <section class="generaciones">
    <h2>Generaciones</h2>
    <div class="generacion-grid">
      
      <!-- Tus cards de generaciones aquí -->
    </div>
  </section>
  
  <br>
  
  <section class="procesos-section">
    <div class="procesos-overlay">
      <h2>Explora nuestros procesos clave</h2>
      <p>Descubre cómo llevamos la calidad a cada etapa.</p>
      <a href="./Procesos.php" class="btn-procesos">Ver procesos</a>
    </div>
  </section>
  
  <br>
  
  <section class="conceptos-section">
    <div class="conceptos-texto">
      <h2>CONCEPTOS CLAVE</h2>
      <p>
        Comprende los principios esenciales que guían nuestros procesos. 
        Desde la mejora continua hasta el control de calidad, esta sección 
        te ayudará a dominar los fundamentos que impulsan la excelencia operativa.
      </p>
      <a href="./Conceptos.php" class="btn-ir">Explorar conceptos</a>
    </div>
    <div class="conceptos-imagen">
      <img src="../IMAGENES/concepto.jpg" alt="Conceptos Clave" />
    </div>
  </section>
  
  <section class="comandos-section">
    <div class="comandos-imagen">
      <img src="../IMAGENES/comando.jpg" alt="Comandos" />
    </div>
    <div class="comandos-texto">
      <h2>COMANDOS ÚTILES</h2>
      <p>
        Descubre los comandos más utilizados para navegar, ejecutar tareas
        y automatizar procesos. Dominar estos atajos puede ahorrarte tiempo 
        y mejorar tu eficiencia significativamente.
      </p>
      <a href="./Comandos.php" class="btn-ir">Ver comandos</a>
    </div>
  </section>

  <script src="../JS/guardarcom.js"></script>
  <script src="../JS/animacion.js"></script>
  
  <?php include '../PHP/footer.php';?>
</body>
</html>
