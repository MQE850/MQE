

<?php
session_start();
if (isset($_SESSION['nombre'])) {
    $nombre_usuario = $_SESSION['nombre'];  // Asignar el nombre de la sesión
} else {
    $nombre_usuario = 'Usuario no autenticado'; // En caso de que no haya sesión
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Introducción a MQE</title>
  <link rel="stylesheet" href="../CSS/introduccion.css" />
  <link rel="stylesheet" href="../CSS/footer.css" />
  <link rel="stylesheet" href="../CSS/Generales.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body>
  <header id="navbar">
    <div class="logo">MQE</div>
    <nav>
      <ul>
        <li><a class="fa-solid fa-house" href="../index.html"></a></li>
      </ul>
    </nav>
  </header>

  <main class="contenido">
    <section class="intro">
      <h1>¿Qué es MQE?</h1>
      <p>
        <strong>MQE</strong> (Manufacturing Quality Engineering) es una disciplina clave en el entorno de manufactura moderna. 
        Su objetivo principal es garantizar que los procesos de producción generen productos que cumplan consistentemente con los estándares de calidad establecidos.
      </p>
      <p>
        Los ingenieros de calidad en manufactura están involucrados desde el diseño del proceso hasta la entrega del producto final, evaluando continuamente 
        cada etapa para identificar riesgos, mitigar errores y mejorar el rendimiento de la producción.
      </p>
      <p>
        MQE combina conocimientos técnicos, análisis de datos, normativas de calidad y metodologías como Six Sigma, Lean Manufacturing o SPC 
        (Control Estadístico de Procesos), para lograr una producción eficiente, segura y de alta calidad.
      </p>
    </section>

    <section class="objetivos">
      <h2>Objetivos de MQE</h2>
      <ul>
        <li><i class="fas fa-check-circle"></i> Reducir defectos en el proceso de manufactura.</li>
        <li><i class="fas fa-check-circle"></i> Aumentar la satisfacción del cliente.</li>
        <li><i class="fas fa-check-circle"></i> Asegurar la trazabilidad y cumplimiento de normas.</li>
        <li><i class="fas fa-check-circle"></i> Apoyar auditorías internas y externas.</li>
        <li><i class="fas fa-check-circle"></i> Implementar mejoras continuas basadas en datos.</li>
        <li><i class="fas fa-check-circle"></i> Fomentar la cultura de calidad en toda la organización.</li>
      </ul>
    </section>

    <section class="galeria">
        <h2>Áreas Clave de MQE</h2>
        <div class="tarjetas-grid">
          
          <div class="tarjeta">
            <img src="../IMAGENES/aucal.png" alt="Auditoría de calidad">
            <div class="contenido-tarjeta">
              <h3>Auditorías de Calidad</h3>
              <p>Evaluación periódica de procesos y productos para verificar el cumplimiento de los estándares establecidos.</p>
            </div>
          </div>
      
          <div class="tarjeta">
            <img src="../IMAGENES/fmea.webp" alt="Análisis de causa raíz">
            <div class="contenido-tarjeta">
              <h3>Análisis de Causa Raíz</h3>
              <p>Detección y eliminación de la causa principal de defectos mediante herramientas como 5 Whys, Ishikawa y FMEA.</p>
            </div>
          </div>
      
          <div class="tarjeta">
            <img src="../IMAGENES/valipro.jpg" alt="Validación de procesos">
            <div class="contenido-tarjeta">
              <h3>Validación de Procesos</h3>
              <p>Confirmación documentada de que un proceso cumple consistentemente con los requisitos definidos.</p>
            </div>
          </div>
      
          <div class="tarjeta">
            <img src="../IMAGENES/control.png" alt="Control estadístico">
            <div class="contenido-tarjeta">
              <h3>Control Estadístico</h3>
              <p>Uso de gráficos SPC y estudios de capacidad para monitorear y mejorar procesos productivos.</p>
            </div>
          </div>
      
        </div>
      </section>
      
      
  </main>
  <script src="../JS/guardarcom.js"></script>
  <?php include '../../PHP/footer.php';?>
</body>
</html>
