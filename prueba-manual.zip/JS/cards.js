const conceptos = [
    {
      titulo: "BIOS",
      descripcion: "Basic Input Output System. Sistema básico que inicia el hardware al encender el equipo.",
      imagen: "https://via.placeholder.com/250x200?text=BIOS"
    },
    {
      titulo: "POST",
      descripcion: "Power-On Self Test. Revisión que hace el equipo al encenderse para verificar el hardware.",
      imagen: "https://via.placeholder.com/250x200?text=POST"
    },
    {
      titulo: "CMOS",
      descripcion: "Memoria donde se guardan configuraciones del BIOS.",
      imagen: "https://via.placeholder.com/250x200?text=CMOS"
    },
    {
      titulo: "UEFI",
      descripcion: "Reemplazo moderno del BIOS con más funciones y seguridad.",
      imagen: "https://via.placeholder.com/250x200?text=UEFI"
    }
  ];
  
  function crearTarjetas(data) {
    const contenedor = document.getElementById("contenedorTarjetas");
    contenedor.innerHTML = "";
  
    data.forEach(({ titulo, descripcion, imagen }) => {
      const card = document.createElement("div");
      card.className = "card";
      card.innerHTML = `
        <div class="card-inner">
          <div class="card-front">
            <img src="${imagen}" alt="${titulo}">
            <h3>${titulo}</h3>
          </div>
          <div class="card-back">
            <h3>${titulo}</h3>
            <p>${descripcion}</p>
          </div>
        </div>
      `;
      contenedor.appendChild(card);
    });
  }
  
  function filtrarTarjetas() {
    const valor = document.getElementById("buscarInput").value.toLowerCase();
    const filtradas = conceptos.filter(c => c.titulo.toLowerCase().includes(valor));
  
    if (filtradas.length > 0) {
      crearTarjetas(filtradas);
    } else {
      document.getElementById("popup").style.display = "block";
      setTimeout(() => {
        document.getElementById("popup").style.display = "none";
      }, 2000);
    }
  }
  
  document.addEventListener("DOMContentLoaded", () => {
    crearTarjetas(conceptos);
  });
  