document.addEventListener("DOMContentLoaded", () => {
    const formulario = document.getElementById("formulario");
    const listaProcesos = document.getElementById("listaProcesos");
    const buscador = document.getElementById("buscador");
  
    // Agregar nuevo proceso
    formulario.addEventListener("submit", (e) => {
      e.preventDefault();
      const nombre = document.getElementById("nombreProceso").value.trim();
      if (nombre !== "") {
        const li = document.createElement("li");
        li.textContent = nombre;
        listaProcesos.appendChild(li);
        formulario.reset();
      }
    });
  
    // Filtro de procesos
    buscador.addEventListener("input", () => {
      const filtro = buscador.value.toLowerCase();
      const procesos = listaProcesos.getElementsByTagName("li");
      Array.from(procesos).forEach((proceso) => {
        const texto = proceso.textContent.toLowerCase();
        proceso.style.display = texto.includes(filtro) ? "block" : "none";
      });
    });
  });
  
  document.addEventListener("DOMContentLoaded", () => {
    const formulario = document.getElementById("formulario");
    const listaProcesos = document.getElementById("listaProcesos");
    const buscador = document.getElementById("buscador");
  
    formulario.addEventListener("submit", (e) => {
      e.preventDefault();
  
      const nombre = document.getElementById("nombreProceso").value.trim();
      const creador = document.getElementById("creador").value.trim();
      const fecha = document.getElementById("fecha").value;
      const palabras = document.getElementById("palabrasClave").value.trim();
      const descripcion = document.getElementById("descripcion").value.trim();
  
      if (nombre && creador && fecha && palabras && descripcion) {
        const li = document.createElement("li");
  
        li.innerHTML = `
          <div class="proceso-item">
            <strong>Nombre:</strong> ${nombre}<br>
            <strong>Creado por:</strong> ${creador}<br>
            <strong>Fecha:</strong> ${fecha}<br>
            <strong>Palabras clave:</strong> ${palabras}<br>
            <strong>Descripción:</strong> ${descripcion}
          </div>
        `;
  
        listaProcesos.appendChild(li);
        formulario.reset();
      }
    });
  
    buscador.addEventListener("input", () => {
      const filtro = buscador.value.toLowerCase();
      const procesos = listaProcesos.getElementsByTagName("li");
  
      Array.from(procesos).forEach((proceso) => {
        const texto = proceso.textContent.toLowerCase();
        proceso.style.display = texto.includes(filtro) ? "block" : "none";
      });
    });
  });
  const buscador = document.getElementById("buscador");
  const generacionSelect = document.getElementById("generacion");
  const procesos = document.querySelectorAll("#listaProcesos li");

  function filtrarProcesos() {
    const texto = buscador.value.toLowerCase();
    const generacion = generacionSelect.value.toLowerCase();

    procesos.forEach(proceso => {
      const contenido = proceso.textContent.toLowerCase();
      const coincideTexto = contenido.includes(texto);
      const coincideGeneracion = generacion === "" || contenido.includes(generacion);

      if (coincideTexto && coincideGeneracion) {
        proceso.style.display = "block";
      } else {
        proceso.style.display = "none";
      }
    });
  }

  buscador.addEventListener("input", filtrarProcesos);
  generacionSelect.addEventListener("change", filtrarProcesos);
  function seleccionarProceso(elemento, id) {
    document.querySelectorAll('.proceso-container').forEach(p => p.classList.remove('seleccionado'));
    elemento.classList.add('seleccionado');
  
    // Cargar detalles del proceso
    cargarDetalle(id);
  }
  
  function cargarDetalle(id) {
    fetch(`../PHP/detalle_proceso.php?id_proceso=${id}`)
      .then(res => res.text())
      .then(html => document.getElementById("detalleProceso").innerHTML = html);
  }
  