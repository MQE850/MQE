const datos = [
    {titulo: "Reset/Reboot SOC",imagen: "../IMAGENES/reset_soc.jpg",comando: "cerberus_utility.exe -s 53 -m 70 -c 8 --slave --private socreset",desc: "Reinicia el SOC desde CMD o PowerShell"},
    {titulo: "Set Boot Mode (SOC)",imagen: "../IMAGENES/set_boot_mode.jpg",comando: "cerberus_utility.exe -s 53 -m 70 -c 8 --slave --private socsetbootmode 1",desc: "Configura el boot mode del SOC"},
    {titulo: "Get Boot Mode (SOC)",imagen: "../IMAGENES/get_boot_mode.jpg",comando: "cerberus_utility.exe -s 53 -m 70 -c 8 --slave --private socgetbootmode",desc: "Lee el boot mode actual del SOC"},
    {titulo: "Check Cerberus FW (Host)",imagen: "../IMAGENES/check_cerberus_fw.png",comando: "cerberus_utility fwversion",desc: "Consulta la versión del firmware en host"},
    {titulo: "Update SOC Image",imagen: "../IMAGENES/update_soc_image.jpg",comando: `cd /tmp/ && mount /dev/sda1 /tmp/usb &&cerberus_utility pfmupdate 0 /tmp/usb/A2040.FIP.PFM.36.bin 0 &&cerberus_utility socfwupdate 0 /tmp/usb/fip.bin`,desc: "Actualiza imagen SOC desde USB"},
    {titulo: "Mount SOC Image",imagen: "../IMAGENES/mount_soc_image.webp",comando: "set system remotedrive mount -i 31 -b 1 -n overlake1908.5.13061236.img",desc: "Monta imagen de sistema en SOC"},
    {titulo: "Update M.2 FW",imagen: "../IMAGENES/update_m2_fw.webp",comando: "drive-manager.exe firmware update fw-file 0 force 1",desc: "Actualiza firmware de discos M.2"},
    {titulo: "Check Cerberus FW Version (SOC)",imagen: "../IMAGENES/check_fw_version.png",comando: "cerberus_utility.exe -s 53 -m 70 -c 8 --slave fwversion",desc: "Consulta la versión del firmware en SOC"},
    {titulo: "Update Cerberus FW (SOC)",imagen: "../IMAGENES/update_fw_soc.png",comando: "cerberus_utility.exe -s 53 -m 70 -c 8 --slave fwupdate FW.bin",desc: "Actualiza el firmware del SOC"},
    {titulo: "Check SOC Version",imagen: "../IMAGENES/check_soc_version.png",comando: `cat /proc/device-tree/firmware/version && cat /proc/device-tree/firmware/nitro-version`,desc: "Consulta la versión del firmware del SOC"},
    {titulo: "Upload FPGA Image",imagen: "../IMAGENES/upload_fpga.png",comando: `upload fpga image to SOC /home/ovl/ && modprobe catapult &&cd /home/ovl/ &&fpgadiagnostics -writeflashjic CelestialPeak_SysInt_313.314.2641ca46.jic.prd`,desc: "Carga la imagen FPGA en el SOC utilizando Filezilla u otro cliente FTP"},
    {titulo: "Power Off from RM",imagen: "../IMAGENES/power_off_rm.png",comando: `set manager port off i:i 3`,desc: "Apaga el puerto desde el RM"},
    {titulo: "Power On from RM",imagen: "../IMAGENES/power_on_rm.png",comando: `set manager port on i:i 3`,desc: "Enciende el puerto desde el RM"},
    {titulo: "Upgrade M.2 Firmware Version",imagen: "../IMAGENES/upgrade_m2_fw.png",comando: `DriveManager-9.0.1-external-windows-x86_64>drive-manager.exe &&drive-manager.exe firmware update fw-file slot force i:1`,desc: "Actualiza la versión de firmware de M.2"},
    {titulo: "Initialize Hardware Diagnostics",imagen: "../IMAGENES/init_hw_diag.png",comando: `init-hwdiag.sh --start &&check-status.sh --all`,desc: "Inicializa la herramienta de diagnósticos de hardware"},
    {titulo: "Verify Network Configuration",imagen: "../IMAGENES/verify_net_config.png",comando: `netconfig --show &&netconfig --verify`,desc: "Verifica la configuración de red del sistema"},
    {titulo: "Restart Management Service",imagen: "../IMAGENES/restart_mgmt_service.png",comando: `systemctl restart mgmt-service`,desc: "Reinicia el servicio de administración"}
  ];
  
  const carousel = document.getElementById('carrusel');
  const buscador = document.getElementById('buscador');
  
  function crearDonutChart(valor, total) {
    const r = 40;
    const circ = 2 * Math.PI * r;
    const percent = valor / total;
    const offset = circ * (1 - percent);
    return `
      <div class="donut">
        <svg width="100" height="100">
          <circle cx="50" cy="50" r="${r}" stroke="#eee" stroke-width="10" fill="none"/>
          <circle cx="50" cy="50" r="${r}" stroke="#3498db" stroke-width="10" fill="none"
                  stroke-dasharray="${circ}" stroke-dashoffset="${offset}" />
          <text x="50" y="55">${valor}/${total}</text>
        </svg>
      </div>
    `;
  }
  
  function renderizarTarjetas(data) {
    carousel.innerHTML = '';
    data.forEach((item) => {
      const div = document.createElement('div');
      div.className = 'card';
      div.innerHTML = `
        <img src="../../IMG/${item.imagen}" alt="${item.titulo}" class="card-img">
        <h3>${item.titulo}</h3>
        <p class="cmd">${item.comando}</p>
        <p>${item.desc}</p>
        <button class="copy-btn" data-comando="${item.comando}">Copiar Comando</button>
      `;
      carousel.appendChild(div);
    });
  
    // Añadir evento de copia
    const copyButtons = document.querySelectorAll('.copy-btn');
    copyButtons.forEach(button => {
      button.addEventListener('click', () => {
        const comando = button.getAttribute('data-comando');
        copiarAlPortapapeles(comando);
      });
    });
  }  

  function copiarAlPortapapeles(texto) {
    // Creamos un campo de texto temporal
    const input = document.createElement('input');
    input.value = texto;
    document.body.appendChild(input);
  
    // Seleccionamos el contenido y lo copiamos
    input.select();
    document.execCommand('copy');
  
    // Eliminamos el campo de texto temporal
    document.body.removeChild(input);
  
    // Alerta o cambio visual opcional
    alert("Comando copiado al portapapeles");
  }  
  
  function marcarCentro() {
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => card.classList.remove('active'));
    const center = Math.floor(cards.length / 2);
    if (cards[center]) cards[center].classList.add('active');
  }
  
  buscador.addEventListener('input', e => {
    const texto = e.target.value.toLowerCase();
    const filtrados = datos.filter(d => d.titulo.toLowerCase().includes(texto));
    renderizarTarjetas(filtrados);
  });
  
  document.getElementById('next').onclick = () => carousel.scrollBy({ left: 300, behavior: 'smooth' });
  document.getElementById('prev').onclick = () => carousel.scrollBy({ left: -300, behavior: 'smooth' });
  
  // arrastrar con mouse
  let isDown = false, startX, scrollLeft;
  carousel.addEventListener('mousedown', (e) => {
    isDown = true;
    startX = e.pageX;
    scrollLeft = carousel.scrollLeft;
  });
  carousel.addEventListener('mouseup', () => isDown = false);
  carousel.addEventListener('mouseleave', () => isDown = false);
  carousel.addEventListener('mousemove', (e) => {
    if (!isDown) return;
    e.preventDefault();
    const x = e.pageX;
    const walk = (x - startX) * 2;
    carousel.scrollLeft = scrollLeft - walk;
  });
  
  renderizarTarjetas(datos);
  