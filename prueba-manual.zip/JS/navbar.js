document.addEventListener("DOMContentLoaded", function () {
  const btnRegistro = document.getElementById("btn-registro");
  const popup = document.getElementById("popup-registro");
  const closeBtn = document.getElementById("popup-close");

  if (btnRegistro && popup && closeBtn) {
    btnRegistro.addEventListener("click", (e) => {
      e.preventDefault();
      popup.style.display = "flex";
    });

    closeBtn.addEventListener("click", () => {
      popup.style.display = "none";
    });

    window.addEventListener("click", (e) => {
      if (e.target === popup) {
        popup.style.display = "none";
      }
    });
  }
});
