document.addEventListener("DOMContentLoaded", function () {
    // Obtener los elementos del DOM
    const modal = document.getElementById("modal");
    const form = document.getElementById("form-proceso");
    const modalTitle = document.getElementById("modal-title");
    const closeBtn = document.querySelector(".close");
  
    // Verificar que los elementos se hayan cargado correctamente
    if (!modal || !form || !modalTitle || !closeBtn) {
      console.error("Uno o más elementos no se han encontrado.");
      return;
    }
  
    // Abrir el modal cuando se hace clic en el botón
    document.querySelectorAll(".btn-modal").forEach(btn => {
      btn.addEventListener("click", () => {
        console.log('Botón de abrir modal clickeado'); // Verificar si se dispara correctamente
        const action = btn.getAttribute("data-action");
  
        // Resetear el formulario cada vez que se abre el modal
        if (form) {
          form.reset();
        }
  
        // Cambiar el título del modal dependiendo de la acción
        if (action === "agregar") {
          modalTitle.textContent = "Agregar Proceso";
        }
  
        // Mostrar el modal
        modal.style.display = "block";
      });
    });
  
    // Cerrar el modal cuando se hace clic en la 'X'
    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });
  
    // Cerrar el modal si se hace clic fuera de la ventana del modal
    window.addEventListener("click", (e) => {
      if (e.target === modal) {
        modal.style.display = "none";
      }
    });
  });
  