const buscador = document.getElementById("buscador");
const filtro = document.getElementById("generacion");
const listaFiltrada = document.getElementById("listaFiltrada");
const resultados = document.getElementById("resultados");
const detalle = document.getElementById("detalleProceso");

function aplicarFiltro() {
    const texto = buscador.value.toLowerCase();
    const generacion = filtro.value;
    const procesos = document.querySelectorAll("#lista-completa .proceso");
    let encontrados = 0;
    listaFiltrada.innerHTML = '';

    procesos.forEach(p => {
    const coincideTexto = p.textContent.toLowerCase().includes(texto);
    const coincideGen = !generacion || p.dataset.generaciones.includes(generacion);
    if (coincideTexto && coincideGen) {
        const clone = p.cloneNode(true);
        listaFiltrada.appendChild(clone);
        encontrados++;
    }
    });

    resultados.style.display = encontrados > 0 ? 'block' : 'none';

    document.querySelectorAll("#listaFiltrada .proceso").forEach(p => {
    p.addEventListener("click", () => cargarDetalle(p.dataset.id));
    });
}

function cargarDetalle(id) {
    fetch(`../PHP/detalle_proceso.php?id=${id}`)
    .then(res => res.text())
    .then(html => detalle.innerHTML = html);
}

buscador.addEventListener("input", aplicarFiltro);
filtro.addEventListener("change", aplicarFiltro);

document.querySelectorAll("#lista-completa .proceso").forEach(p => {
    p.addEventListener("click", () => cargarDetalle(p.dataset.id));
});