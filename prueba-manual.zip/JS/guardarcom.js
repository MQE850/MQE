document.addEventListener("DOMContentLoaded", function () {
    const btnComentar = document.getElementById("btn-comentar");
    const popup = document.getElementById("popup");
    const popupClose = document.getElementById("popup-close");
    const form = document.getElementById("form-comentario");
    const mensaje = document.getElementById("mensaje");
  
    if (btnComentar && popup && popupClose) {
      btnComentar.addEventListener("click", () => {
        popup.style.display = "flex";
      });
  
      popupClose.addEventListener("click", () => {
        popup.style.display = "none";
      });
  
      window.addEventListener("click", (e) => {
        if (e.target === popup) popup.style.display = "none";
      });
    }
  
    if (form) {
      form.addEventListener("submit", function (e) {
        e.preventDefault();
  
        const noreloj = document.getElementById("noreloj").value.trim();
        const comentario = document.getElementById("comentario").value.trim();
  
        if (!noreloj || !comentario) {
          mensaje.innerHTML = "<p style='color:red;'>Por favor, completa todos los campos.</p>";
          return;
        }
  
        fetch("../../prueba-manual/PHP/guardar_comentario.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: `noreloj=${encodeURIComponent(noreloj)}&comentario=${encodeURIComponent(comentario)}`
        })
          .then(res => {
            if (!res.ok) {
              throw new Error(`Error al enviar el comentario. Código de estado: ${res.status}`);
            }
            return res.json();
          })
          .then(data => {
            if (data.success) {
              mensaje.innerHTML = "<p style='color:green;'>Comentario enviado correctamente.</p>";
              form.reset();
            } else {
              mensaje.innerHTML = `<p style='color:red;'>${data.message}</p>`;
            }
          })
          .catch(err => {
            console.error("Error:", err);
            mensaje.innerHTML = "<p style='color:red;'>Error de conexión.</p>";
          });
      });
    }
  });
  