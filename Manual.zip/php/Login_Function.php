<?php
session_start();

$noreloj = $_POST['noreloj'] ?? '';
$password = $_POST['contrasena'] ?? '';

$sql = "SELECT * FROM empleados WHERE noreloj = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $noreloj);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 1) {
    $usuario = $resultado->fetch_assoc();

    if (password_verify($password, $usuario['contrasena'])) {
        // Guardar datos en la sesión
        $_SESSION['noreloj'] = $usuario['noreloj'];
        $_SESSION['nombre'] = $usuario['nombre'];
        $_SESSION['apellido'] = $usuario['apellido'];
        $_SESSION['rol'] = $usuario['rol'];
        $_SESSION['departamento'] = $usuario['departamento'];
        $_SESSION['fecha_registro'] = $usuario['creado_en'];

        header("Location: ./index.php");
        exit();
    } else {
        header("Location: ../HTML/login.php?error=pass");
        exit();
    }
} else {
    header("Location: ../HTML/login.php?error=nousuario");
    exit();
}

$conn->close();
?>
