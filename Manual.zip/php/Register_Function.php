<?php 
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

$noreloj = $_POST['noreloj'] ?? '';
$nombre = $_POST['nombre'] ?? '';
$apellido = $_POST['apellido'] ?? '';
$rol = $_POST['rol'] ?? 'publico';
$departamento = $_POST['departamento'] ?? '';
$password = $_POST['contrasena'] ?? '';

include'./DB_connection.php';

$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$sql = "INSERT INTO empleados (noreloj, nombre, apellido, rol, departamento, contrasena) 
        VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error en prepare: " . $conn->error);
}

$stmt->bind_param('ssssss', $noreloj, $nombre, $apellido, $rol, $departamento, $hashed_password);

if ($stmt->execute()) {
    // Mostrar mensaje de éxito con JavaScript (popup)
    echo "<script type='text/javascript'>
            alert('Usuario registrado correctamente.');
            window.location.href = './Register_Function.php'; 
          </script>";
} else {
    echo "Error al registrar el usuario: " . $stmt->error;
}

$conn->close();
?>
