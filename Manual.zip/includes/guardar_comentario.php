<?php
session_start();
include('conexion.php');

header('Content-Type: application/json');

$noreloj = $_SESSION['noreloj'] ?? $_POST['noreloj'] ?? '';
$nombre = $_SESSION['nombre'] ?? $_POST['nombre'] ?? '';
$tipo = $_POST['tipo'] ?? 'Comentario'; // valor por defecto
$mensaje = trim($_POST['mensaje'] ?? '');

if ($noreloj && $nombre && $mensaje) {
    $stmt = $conn->prepare("INSERT INTO comentarios_web (noreloj, nombre, tipo, mensaje) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $noreloj, $nombre, $tipo, $mensaje);
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Error al guardar el comentario.']);
    }
} else {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Faltan datos obligatorios.']);
}
?>
