<link rel="stylesheet" href="./css/Footer.css">

<footer class="footer">
  <div class="footer-left">
    <a href=""><i class="fa-solid fa-house"></i> Página Principal</a>
    <a href="../../Manual/webpages/Generation.php">Generaciones</a>
    <a href="../../Manual/webpages/Procesos.php">Procesos</a>
    <a href="../../Manual/webpages/Conceptos.php">Conceptos</a>
    <a href="../../Manual/webpages/Comandos.php">Comandos</a>
  </div>
  <div class="footer-center">
    <button id="btn-comentar">Comenta aquí</button>
  </div>
  <div class="footer-right">
    <p><strong>Contacto:</strong></p>
    <p>Ing. Carlos Rosas - Carlos_Rosas@wiwynn.com</p>
    <p>Ing. Mario Jaquez - Mario_Jaquez@wiwynn.com</p>
  </div>
</footer>


<!-- Popup -->
<div class="popup" id="popup">
  <div class="popup-content">
    <span class="popup-close" id="popup-close">&times;</span>
    <h3>Escribe tu comentario</h3>
    <form id="form-comentario" method="POST" action="../includes/guardar_comentario.php">
      <?php $noreloj = $_SESSION['noreloj'] ?? ''; ?>
      <input
        type="text"
        id="noreloj"
        name="noreloj"
        placeholder="Número de reloj"
        value="<?= htmlspecialchars($noreloj) ?>"
        <?= $noreloj ? 'readonly' : 'required' ?>
      >

      <?php $nombre = $_SESSION['nombre'] ?? ''; ?>
      <input
        type="text"
        id="nombre"
        name="nombre"
        placeholder="Nombre"
        value="<?= htmlspecialchars($nombre) ?>"
        <?= $nombre ? 'readonly' : 'required' ?>
      >

      <label for="tipo">Tipo:</label>
      <select name="tipo" id="tipo" required>
        <option value="Comentario">Comentario</option>
        <option value="Sugerencia">Sugerencia</option>
        <option value="Queja">Queja</option>
      </select>

      <textarea id="comentario" name="mensaje" placeholder="Escribe tu mensaje" required></textarea>

      <button type="submit">Enviar</button>
    </form>

    <div id="mensaje"></div>
  </div>
</div>

<script src="../../Manual/js/guardar-comentario.js"></script>
