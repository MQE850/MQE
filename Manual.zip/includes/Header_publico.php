<link rel="stylesheet" href="./css/Header.css">
<header id="navbar">
  <div class="user-logo">
    <div class="logo">
      <img src="../../Manual/img/MQE_LOGOPUTO.png" alt="MQE Logo" />
    </div>

    <div class="user-info" style="color:white;font-size:1rem;">
      Bienvenido
    </div>
  </div>
  
  <nav>
    <ul>
      <li><a class="fa-solid fa-house" href="" title="Inicio"></a></li>
      <li><a href="../../Manual/webpages/Generation.php">Generación</a></li>
      <li><a href="../../Manual/webpages/Process.php">Procesos</a></li>
      <li><a href="../../Manual/webpages/Concept.php">Conceptos</a></li>
      <li><a href="../../Manual/webpages/Commands.php">Comandos</a></li>
      <li><a href="../../Manual/webpages/Login.php">Iniciar Sesión</a></li>
    </ul>
  </nav>
</header>
