<header id="navbar">
  <div class="user-logo">
    <div class="logo">
      <img src="../img/MQE_LOGOPUTO.png" alt="MQE Logo" />
    </div>

    <div class="user-info" style="color:white;">
      Bienvenido, <?= htmlspecialchars($nombre) ?> (<?= htmlspecialchars($departamento) ?>)
    </div>
  </div>
  
  <nav>
    <ul>
      <li><a class="fa-solid fa-house" href="" title="Inicio"></a></li>
      <li><a href="../webpages/Generation.php">Generación</a></li>
      <li><a href="../webpages/Process.php">Procesos</a></li>
      <li><a href="../webpages/Concept.php">Conceptos</a></li>
      <li><a href="../webpages/Commands.php">Comandos</a></li>
      <li><a class="fa-solid fa-users" href="#" id="btn-registro" title="Registro de usuarios"></a></li>
    <li><a class="fa-solid fa-right-from-bracket" href="../PHP/logout.php" title="Cerrar sesión"></a></li>
    </ul>
  </nav>
</header>

<script>
  document.addEventListener("DOMContentLoaded", () => {
    const btnRegistro = document.getElementById("btn-registro");
    const modal = document.getElementById("modal-registro");
    const btnClose = document.getElementById("close-registro");

    if (btnRegistro && modal && btnClose) {
      btnRegistro.addEventListener("click", e => {
        e.preventDefault();
        modal.style.display = "flex";
      });

      btnClose.addEventListener("click", () => {
        modal.style.display = "none";
      });

      window.addEventListener("click", (e) => {
        if (e.target === modal) {
          modal.style.display = "none";
        }
      });
    }
  });
</script>
