<?php 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Validar si el usuario está autenticado
if (!isset($_SESSION['noreloj'])) {
    // Si no está logueado, redirige al login
    header('Location: ../webpages/Login.php');
    exit();
}

// Guarda el nombre de la pagina actualmente cargada
$pagina = basename($_SERVER['PHP_SELF']); // ejemplo: admin.php

// Redirigir según rol
if ($pagina === 'admin.php' && $_SESSION['rol'] !== 'admin') {
    header('Location: ../html/index.php');
    exit();
}
if ($pagina === 'empleado.php' && $_SESSION['rol'] !== 'empleado') {
    header('Location: ../html/index.php');
    exit();
}

$noreloj = $_SESSION['noreloj'] ?? null;
$rol = $_SESSION['rol'] ?? 'publico';
$nombre = $_SESSION['nombre'] ?? 'Invitado';
$departamento = $_SESSION['departamento'] ?? '';
?>