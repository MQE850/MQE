window.onload = function () {
  const params = new URLSearchParams(window.location.search);
  const error = params.get("error");

  if (error) {
      let mensaje = "";

      switch (error) {
          case "nousuario":
              mensaje = "El usuario no está registrado.";
              break;
          case "pass":
              mensaje = "La contraseña es incorrecta.";
              break;
          case "sinacceso":
              mensaje = "El usuario no tiene acceso autorizado.";
              break;
          default:
              mensaje = "Error desconocido.";
      }

      Swal.fire({
          icon: 'error',
          title: 'Error de inicio de sesión',
          text: mensaje
      });
  }
};
