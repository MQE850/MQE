const popup = document.getElementById("popup");
const popupBackground = document.getElementById("popup-background");
const btnComentar = document.getElementById("btn-comentar");
const popupClose = document.getElementById("popup-close");

btnComentar.addEventListener("click", () => {
  popup.style.display = "block";
  popupBackground.style.display = "block";
});

popupClose.addEventListener("click", () => {
  popup.style.display = "none";
  popupBackground.style.display = "none";
  document.getElementById("mensaje").innerText = '';
});
