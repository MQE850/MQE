document.getElementById("btn-comentar").addEventListener("click", () => {
  document.getElementById("popup").style.display = "block";
});

document.getElementById("popup-close").addEventListener("click", () => {
  document.getElementById("popup").style.display = "none";
  document.getElementById("mensaje").innerText = '';
});

document.getElementById("form-comentario").addEventListener("submit", function (e) {
  e.preventDefault();

  const noreloj = document.getElementById("noreloj").value.trim();
  const comentario = document.getElementById("comentario").value.trim();

  if (!noreloj || !comentario) {
    document.getElementById("mensaje").innerText = "Por favor, completa todos los campos.";
    return;
  }

  const formData = new FormData(this);

  fetch("../includes/guardar_comentario.php", {
    method: "POST",
    body: formData,
  })
    .then(res => {
      if (!res.ok) throw new Error('Error en la respuesta del servidor');
      return res.json();
    })
    .then(data => {
      if (data.success) {
        document.getElementById("mensaje").innerText = "Comentario guardado correctamente.";
        document.getElementById("form-comentario").reset();
        // Mantener valor noreloj si está readonly
        if (document.getElementById("noreloj").hasAttribute("readonly")) {
          document.getElementById("noreloj").value = document.getElementById("noreloj").getAttribute("value");
        }
      } else {
        document.getElementById("mensaje").innerText = data.message || "Ocurrió un error.";
      }
    })
    .catch(err => {
      document.getElementById("mensaje").innerText = "Error en la solicitud.";
      console.error(err);
    });
});
